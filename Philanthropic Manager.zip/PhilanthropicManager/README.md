# PhilanthropicManager
 Applicativo para gestao filantrópica
